# Deploying on Vercel

1. Upload this folder to your GitHub repository (replace the old files).
2. In Vercel → your project → Settings → Environment Variables, add these three
   (for Production, Preview and Development), then redeploy once:

   VITE_SUPABASE_URL = https://c--5602fe20-b07b-4d97-b810-65016b404887-prod.lovable.cloud
   VITE_SUPABASE_PUBLISHABLE_KEY = sb_publishable_8recokiPo3ZpKBoGHyaG6w_8F5YOr5L
   VITE_SUPABASE_PROJECT_ID = ihauhvglcfvdaykihgrf

   These are public keys (safe to use in the browser). No secret keys are needed.

3. Open https://YOUR-SITE/admin on your phone.
   - First time: tap "First time? Set up account", choose a password, then tap the
     confirmation link sent to yetundebalogun74@gmail.com.
   - After that, just log in.

Replacing a photo or video updates the live site within about a minute. No redeploy needed.
Edit business details in src/lib/site.ts. Original photos/videos are in public/media/.
