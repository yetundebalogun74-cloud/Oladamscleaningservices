import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { MEDIA_SLOTS, type MediaSlot } from "@/lib/media-slots";
import { overridesQuery, type Override } from "@/lib/use-media";

const ADMIN_EMAIL = "yetundebalogun74@gmail.com"; // UI hint only; access is enforced by database rules.
const BUCKET = "site-media";
const TEN_YEARS = 60 * 60 * 24 * 365 * 10;

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Media Dashboard | Excellent Amazing" },
      { name: "description", content: "Private dashboard for replacing website photos and videos." },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: "Media Dashboard" },
      { property: "og:description", content: "Private administrator area." },
    ],
  }),
  component: AdminPage,
});

function AdminPage() {
  const [session, setSession] = useState<Session | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setReady(true);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  if (!ready) return <Shell><p className="text-muted-foreground">Loading…</p></Shell>;
  if (!session) return <Shell><Login /></Shell>;
  return <Gate session={session} />;
}

function Shell({ children, onLogout }: { children: React.ReactNode; onLogout?: () => void }) {
  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 sm:py-12">
      <div className="mb-8 flex items-center justify-between gap-4">
        <div className="min-w-0">
          <p className="eyebrow">Administrator</p>
          <h1 className="mt-1 text-2xl font-medium sm:text-3xl">Media Dashboard</h1>
        </div>
        {onLogout && <button onClick={onLogout} className="btn btn-outline shrink-0 text-primary">Log Out</button>}
      </div>
      {children}
    </div>
  );
}

function Login() {
  const [mode, setMode] = useState<"in" | "setup" | "reset">("in");
  const [email, setEmail] = useState(ADMIN_EMAIL);
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg(null);
    if (email.trim().toLowerCase() !== ADMIN_EMAIL) {
      setMsg({ ok: false, text: "This email is not authorised to manage the website." });
      return;
    }
    setBusy(true);
    const redirect = `${window.location.origin}/admin`;
    const res =
      mode === "in"
        ? await supabase.auth.signInWithPassword({ email, password })
        : mode === "setup"
          ? await supabase.auth.signUp({ email, password, options: { emailRedirectTo: redirect } })
          : await supabase.auth.resetPasswordForEmail(email, { redirectTo: redirect });
    setBusy(false);
    if (res.error) return setMsg({ ok: false, text: res.error.message });
    if (mode === "setup") setMsg({ ok: true, text: "Check your email and tap the confirmation link, then log in here." });
    if (mode === "reset") setMsg({ ok: true, text: "Password reset email sent. Follow the link to set a new password." });
  };

  return (
    <form onSubmit={submit} className="mx-auto max-w-md space-y-5 rounded-lg border bg-card p-6 sm:p-8">
      <h2 className="text-xl font-medium">{mode === "in" ? "Log in" : mode === "setup" ? "First-time setup" : "Reset password"}</h2>
      <label className="block">
        <span className="text-sm font-semibold">Email</span>
        <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email"
          className="mt-2 h-12 w-full rounded-md border border-input bg-background px-3 text-base" />
      </label>
      {mode !== "reset" && (
        <label className="block">
          <span className="text-sm font-semibold">{mode === "setup" ? "Choose a password" : "Password"}</span>
          <input type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)}
            autoComplete={mode === "setup" ? "new-password" : "current-password"}
            className="mt-2 h-12 w-full rounded-md border border-input bg-background px-3 text-base" />
        </label>
      )}
      {msg && <p className={`rounded-md p-3 text-sm ${msg.ok ? "bg-secondary text-secondary-foreground" : "bg-destructive/10 text-destructive"}`}>{msg.text}</p>}
      <button disabled={busy} className="btn btn-primary w-full">{busy ? "Please wait…" : mode === "in" ? "Log In" : mode === "setup" ? "Create Account" : "Send Reset Email"}</button>
      <div className="flex flex-wrap justify-between gap-2 text-sm">
        {mode !== "in" && <button type="button" onClick={() => setMode("in")} className="font-semibold text-primary">Back to log in</button>}
        {mode === "in" && <button type="button" onClick={() => setMode("setup")} className="font-semibold text-primary">First time? Set up account</button>}
        {mode === "in" && <button type="button" onClick={() => setMode("reset")} className="font-semibold text-primary">Forgot password?</button>}
      </div>
    </form>
  );
}

function Gate({ session }: { session: Session }) {
  const { data: isAdmin, isLoading } = useQuery({
    queryKey: ["is-admin", session.user.id],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("has_role", { _user_id: session.user.id, _role: "admin" });
      if (error) throw error;
      return !!data;
    },
  });
  const logout = () => supabase.auth.signOut();

  if (isLoading) return <Shell onLogout={logout}><p className="text-muted-foreground">Checking access…</p></Shell>;
  if (!isAdmin)
    return (
      <Shell onLogout={logout}>
        <p className="rounded-md bg-destructive/10 p-4 text-destructive">This account is not authorised to manage website media.</p>
      </Shell>
    );
  return <Shell onLogout={logout}><Dashboard /></Shell>;
}

function Dashboard() {
  const { data: overrides = [] } = useQuery(overridesQuery);
  const groups = useMemo(() => {
    const g = new Map<string, MediaSlot[]>();
    for (const s of MEDIA_SLOTS) g.set(s.group, [...(g.get(s.group) ?? []), s]);
    return [...g.entries()];
  }, []);
  const [open, setOpen] = useState<string | null>(groups[0]?.[0] ?? null);

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Tap a section, choose the photo or video you want to change, then preview and save. Changes appear on the live website within a minute.
      </p>
      {groups.map(([group, slots]) => (
        <section key={group} className="overflow-hidden rounded-lg border bg-card">
          <button onClick={() => setOpen(open === group ? null : group)} className="flex w-full items-center justify-between gap-3 p-4 text-left sm:p-5">
            <span className="font-semibold">{group}</span>
            <span className="text-sm text-muted-foreground">{slots.length} · {open === group ? "Hide" : "Show"}</span>
          </button>
          {open === group && (
            <div className="grid gap-4 border-t p-4 sm:grid-cols-2 sm:p-5 lg:grid-cols-3">
              {slots.map((s) => <SlotCard key={s.id} slot={s} overrides={overrides} />)}
            </div>
          )}
        </section>
      ))}
    </div>
  );
}

function uploadWithProgress(path: string, file: File, token: string, onProgress: (p: number) => void) {
  const base = import.meta.env["VITE_SUPABASE_URL"] as string;
  const key = import.meta.env["VITE_SUPABASE_PUBLISHABLE_KEY"] as string;
  return new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", `${base}/storage/v1/object/${BUCKET}/${path}`);
    xhr.setRequestHeader("Authorization", `Bearer ${token}`);
    xhr.setRequestHeader("apikey", key);
    xhr.setRequestHeader("Content-Type", file.type || "application/octet-stream");
    xhr.setRequestHeader("x-upsert", "false");
    xhr.upload.onprogress = (e) => e.lengthComputable && onProgress(Math.round((e.loaded / e.total) * 100));
    xhr.onload = () => (xhr.status < 300 ? resolve() : reject(new Error(`Upload failed (${xhr.status}): ${xhr.responseText}`)));
    xhr.onerror = () => reject(new Error("Upload failed. Check your internet connection."));
    xhr.send(file);
  });
}

function SlotCard({ slot, overrides }: { slot: MediaSlot; overrides: Override[] }) {
  const qc = useQueryClient();
  const current = overrides.find((o) => o.slot === slot.id);
  const currentUrl = current?.url ?? slot.fallback;
  const isVideo = slot.kind === "video";
  const fileRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [linkUrl, setLinkUrl] = useState("");
  const [showLink, setShowLink] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const [big, setBig] = useState(false);
  const [progress, setProgress] = useState<number | null>(null);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  useEffect(() => () => { if (preview?.startsWith("blob:")) URL.revokeObjectURL(preview); }, [preview]);

  const pick = (f: File | undefined) => {
    setMsg(null);
    if (!f) return;
    const ok = isVideo ? f.type.startsWith("video/") : f.type.startsWith("image/");
    if (!ok) return setMsg({ ok: false, text: `Please choose ${isVideo ? "a video" : "an image"} file.` });
    if (f.size > 50 * 1024 * 1024) return setMsg({ ok: false, text: "File is larger than 50 MB. Please choose a smaller file." });
    setFile(f);
    setPreview(URL.createObjectURL(f));
  };

  const useLink = () => {
    setMsg(null);
    try {
      const u = new URL(linkUrl.trim());
      if (u.protocol !== "https:" || !/\.(mp4|webm|mov|m4v)(\?|$)/i.test(u.pathname + u.search))
        throw new Error();
      setFile(null);
      setPreview(u.toString());
    } catch {
      setMsg({ ok: false, text: "Use a direct https link to a video file ending in .mp4, .webm or .mov." });
    }
  };

  const cancel = () => {
    setFile(null); setPreview(null); setLinkUrl(""); setShowLink(false); setBig(false); setProgress(null);
    if (fileRef.current) fileRef.current.value = "";
  };

  const save = async () => {
    if (!preview) return;
    setMsg(null);
    try {
      const { data: s } = await supabase.auth.getSession();
      const token = s.session?.access_token;
      if (!token) throw new Error("Your session expired. Please log in again.");
      let url = preview;
      let storagePath: string | null = null;
      if (file) {
        const ext = (file.name.split(".").pop() || (isVideo ? "mp4" : "jpg")).toLowerCase().replace(/[^a-z0-9]/g, "");
        storagePath = `${slot.id}/${Date.now()}.${ext}`;
        setProgress(0);
        await uploadWithProgress(storagePath, file, token, setProgress);
        const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(storagePath, TEN_YEARS);
        if (error || !data) throw error ?? new Error("Could not create link for the uploaded file.");
        url = data.signedUrl;
      }
      const { error } = await supabase.from("media_overrides").upsert({ slot: slot.id, url, storage_path: storagePath, updated_at: new Date().toISOString() });
      if (error) throw error;

      // Remove the previous uploaded file only if no other position still uses it.
      const old = current?.storage_path;
      if (old && old !== storagePath) {
        const { data: users } = await supabase.from("media_overrides").select("slot").eq("storage_path", old);
        if (!users?.length) await supabase.storage.from(BUCKET).remove([old]);
      }
      await qc.invalidateQueries({ queryKey: overridesQuery.queryKey });
      cancel();
      setMsg({ ok: true, text: "Saved. The website now shows the new " + (isVideo ? "video." : "image.") });
    } catch (e) {
      setProgress(null);
      setMsg({ ok: false, text: e instanceof Error ? e.message : "Something went wrong. Please try again." });
    }
  };

  const shown = preview ?? currentUrl;
  const busy = progress !== null;

  return (
    <div className="flex flex-col rounded-md border bg-background p-3">
      <div className="relative overflow-hidden rounded bg-muted">
        {isVideo ? (
          <video key={shown} src={shown} poster={preview || current ? undefined : slot.poster} controls playsInline muted preload="metadata" className="aspect-[9/16] max-h-80 w-full object-contain" />
        ) : (
          <img src={shown} alt={slot.label} className="aspect-[4/3] w-full object-cover" />
        )}
        {preview && <span className="absolute left-2 top-2 rounded bg-accent px-2 py-0.5 text-xs font-bold text-accent-foreground">New — not saved</span>}
      </div>
      <p className="mt-3 text-sm font-semibold">{slot.label}</p>
      <p className="text-xs text-muted-foreground">{current ? "Replaced" : "Original"}</p>

      <input ref={fileRef} type="file" accept={isVideo ? "video/*" : "image/*"} className="hidden" onChange={(e) => pick(e.target.files?.[0])} />

      {!preview && !busy && (
        <div className="mt-3 grid gap-2">
          <button onClick={() => fileRef.current?.click()} className="btn btn-primary">{isVideo ? "Replace Video" : "Replace Image"}</button>
          {isVideo && !showLink && <button onClick={() => setShowLink(true)} className="text-sm font-semibold text-primary">Use a video link instead</button>}
          {isVideo && showLink && (
            <div className="grid gap-2">
              <input value={linkUrl} onChange={(e) => setLinkUrl(e.target.value)} placeholder="https://…/video.mp4" inputMode="url"
                className="h-11 w-full rounded-md border border-input bg-background px-3 text-sm" />
              <div className="grid grid-cols-2 gap-2">
                <button onClick={useLink} className="btn btn-outline px-2 text-primary">Preview</button>
                <button onClick={cancel} className="btn btn-outline px-2">Cancel</button>
              </div>
            </div>
          )}
        </div>
      )}

      {preview && !busy && (
        <div className="mt-3 grid grid-cols-2 gap-2">
          <button onClick={() => setBig(true)} className="btn btn-outline px-2 text-primary">Preview</button>
          <button onClick={cancel} className="btn btn-outline px-2">Cancel</button>
          <button onClick={save} className="btn btn-primary col-span-2">Save Changes</button>
        </div>
      )}

      {busy && (
        <div className="mt-3">
          <div className="h-2 overflow-hidden rounded-full bg-muted"><div className="h-full bg-primary transition-all" style={{ width: `${progress}%` }} /></div>
          <p className="mt-1 text-xs text-muted-foreground">Uploading… {progress}%</p>
        </div>
      )}

      {msg && <p className={`mt-3 rounded p-2 text-xs ${msg.ok ? "bg-secondary text-secondary-foreground" : "bg-destructive/10 text-destructive"}`}>{msg.text}</p>}

      {big && preview && (
        <div className="fixed inset-0 z-[60] flex flex-col items-center justify-center gap-4 bg-ink/90 p-4" onClick={() => setBig(false)}>
          {isVideo ? (
            <video src={preview} controls autoPlay playsInline className="max-h-[80vh] max-w-full rounded" onClick={(e) => e.stopPropagation()} />
          ) : (
            <img src={preview} alt="Preview" className="max-h-[80vh] max-w-full rounded object-contain" />
          )}
          <button className="btn btn-accent">Close Preview</button>
        </div>
      )}
    </div>
  );
}

