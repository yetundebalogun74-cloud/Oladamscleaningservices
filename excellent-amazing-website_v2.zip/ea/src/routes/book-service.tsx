import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ArrowLeft, Check } from "lucide-react";
import { CLEANING, PEST, FLORA, PRICES, TIME_SLOTS, createWhatsAppLink, pestMessage, floraMessage, tierMessage, type CleaningCategory } from "@/lib/site";
import { useMedia } from "@/lib/use-media";
import { WhatsAppIcon } from "@/components/site/Chrome";

type ServiceId = "cleaning" | "pest" | "flora";

export const Route = createFileRoute("/book-service")({
  validateSearch: (s: Record<string, unknown>): { service?: ServiceId } => {
    const v = s["service"];
    return v === "cleaning" || v === "pest" || v === "flora" ? { service: v } : {};
  },
  head: () => ({
    meta: [
      { title: "Book a Service | Excellent Amazing Cleaning and Pest Control" },
      { name: "description", content: "Book cleaning, formigation / pest control or floriculture services in Alimosho, Lagos. Your booking is sent to us on WhatsApp." },
      { property: "og:title", content: "Book a Service — Excellent Amazing" },
      { property: "og:description", content: "Choose your service and category, then send your booking to us on WhatsApp." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: BookService,
});

const SERVICES: { id: ServiceId; name: string; img: string; desc: string }[] = [
  { id: "cleaning", name: "Cleaning Service", img: "booking.cleaning", desc: "Residential, office, move-in / out, sofa, rug and mattress." },
  { id: "pest", name: "Formigation / Pest Control Service", img: "booking.pest", desc: "Cockroaches, ants, mosquitoes, bedbugs, termites, rodents." },
  { id: "flora", name: "Floriculture Service", img: "booking.flora", desc: "Landscaping, planting, gardens and supplies." },
];

type Details = { name: string; phone: string; email: string; address: string; date: string; time: string };
const EMPTY: Details = { name: "", phone: "", email: "", address: "", date: "", time: "" };

const todayISO = () => {
  const d = new Date();
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 10);
};
const fmtDate = (iso: string) =>
  new Date(iso + "T00:00:00").toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "long", year: "numeric" });

function BookService() {
  const { m } = useMedia();
  const search = Route.useSearch();
  const [service, setService] = useState<ServiceId | null>(search.service ?? null);
  const [category, setCategory] = useState<CleaningCategory | null>(null);
  const [details, setDetails] = useState<Details>(EMPTY);
  const [reviewing, setReviewing] = useState(false);

  const steps = useMemo(() => {
    if (service === "cleaning" && category?.flow === "form") return ["Service", "Category", "Details", "Booking", "WhatsApp"];
    if (service === "cleaning" && category?.flow === "tier") return ["Service", "Category", "Price", "WhatsApp"];
    if (service === "cleaning") return ["Service", "Category", "Details", "Booking", "WhatsApp"];
    if (service) return ["Service", "Category", "WhatsApp"];
    return ["Service", "Category", "WhatsApp"];
  }, [service, category]);

  const current = !service ? 0 : !category ? 1 : category.flow === "tier" ? 2 : reviewing ? 3 : 2;

  const reset = () => { setService(null); setCategory(null); setDetails(EMPTY); setReviewing(false); };
  const back = () => {
    if (reviewing) return setReviewing(false);
    if (category) return setCategory(null);
    reset();
  };

  return (
    <div className="bg-background">
      <section className="border-b bg-ink text-ink-foreground">
        <div className="mx-auto max-w-5xl px-5 py-12 lg:px-8 lg:py-16">
          <p className="eyebrow text-accent">Book a service</p>
          <h1 className="mt-3 text-4xl font-medium sm:text-5xl">What service do you need?</h1>
          <p className="mt-4 max-w-xl text-ink-foreground/70">Choose a service and category. Your message is prepared for WhatsApp — you just press send.</p>
          <ol className="mt-10 flex flex-wrap items-center gap-x-2 gap-y-3 text-xs font-bold uppercase tracking-wider" aria-label="Progress">
            {steps.map((s, i) => (
              <li key={s} className="flex items-center gap-2">
                <span className={`grid h-7 w-7 place-items-center rounded-full border ${i < current ? "border-accent bg-accent text-accent-foreground" : i === current ? "border-accent text-accent" : "border-ink-foreground/25 text-ink-foreground/50"}`}>
                  {i < current ? <Check className="h-3.5 w-3.5" /> : i + 1}
                </span>
                <span className={i <= current ? "text-ink-foreground" : "text-ink-foreground/50"}>{s}</span>
                {i < steps.length - 1 && <span className="mx-1 text-ink-foreground/30">→</span>}
              </li>
            ))}
          </ol>
        </div>
      </section>

      <div className="mx-auto max-w-5xl px-5 py-12 lg:px-8 lg:py-16">
        {service && (
          <button onClick={back} className="mb-8 inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline">
            <ArrowLeft className="h-4 w-4" />Back
          </button>
        )}

        {!service && (
          <div className="grid gap-5 md:grid-cols-3">
            {SERVICES.map((s) => (
              <button key={s.id} onClick={() => setService(s.id)} className="group overflow-hidden rounded-lg border bg-card text-left transition-colors hover:border-primary">
                <img src={m(s.img)} alt="" className="aspect-[4/3] w-full object-cover" />
                <div className="p-6">
                  <h2 className="text-xl font-medium">{s.name}</h2>
                  <p className="mt-2 text-sm text-muted-foreground">{s.desc}</p>
                </div>
              </button>
            ))}
          </div>
        )}

        {service === "cleaning" && !category && (
          <Step title="Choose your cleaning category">
            <div className="grid gap-3 sm:grid-cols-2">
              {CLEANING.map((c) => (
                <button key={c.id} onClick={() => setCategory(c)} className="rounded-lg border bg-card p-6 text-left transition-colors hover:border-primary">
                  <h3 className="font-sans text-base font-semibold">{c.name}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{c.desc}</p>
                  {c.flow === "tier" && <p className="mt-3 text-xs font-bold uppercase tracking-wider text-primary">Basic or Premium</p>}
                </button>
              ))}
            </div>
          </Step>
        )}

        {service === "cleaning" && category?.flow === "tier" && (
          <Step title={`${category.name} — choose an option`} intro="WhatsApp opens with your message ready. We'll reply with the booking details.">
            <div className="grid gap-4 sm:grid-cols-2">
              {(["Basic", "Premium"] as const).map((tier) => {
                const price = PRICES[`${category.id}:${tier.toLowerCase()}`];
                return (
                  <a key={tier} href={createWhatsAppLink(tierMessage(category.item, tier))} target="_blank" rel="noopener noreferrer"
                    className={`flex flex-col rounded-lg border p-7 transition-colors hover:border-primary ${tier === "Premium" ? "bg-primary text-primary-foreground" : "bg-card"}`}>
                    <span className="eyebrow" style={{ color: "inherit" }}>{tier}</span>
                    <span className="mt-3 font-display text-2xl">{tier} {category.item}</span>
                    {price && <span className="mt-2 text-lg font-semibold">{price}</span>}
                    <span className="btn btn-whatsapp mt-6"><WhatsAppIcon />{tier === "Basic" ? `${category.item.split(" ")[0]} Basic` : `${category.item.split(" ")[0]} Premium`}</span>
                  </a>
                );
              })}
            </div>
          </Step>
        )}

        {service === "cleaning" && category?.flow === "form" && !reviewing && (
          <Step title="Your details" intro={category.name}>
            <form
              onSubmit={(e) => { e.preventDefault(); setReviewing(true); window.scrollTo({ top: 0, behavior: "smooth" }); }}
              className="grid gap-5 rounded-lg border bg-card p-6 sm:grid-cols-2 sm:p-8"
            >
              <Field label="Full Name" value={details.name} onChange={(v) => setDetails({ ...details, name: v })} autoComplete="name" />
              <Field label="Phone Number" type="tel" value={details.phone} onChange={(v) => setDetails({ ...details, phone: v })} autoComplete="tel" pattern="[0-9+\s\-]{7,}" />
              <Field label="Email Address" type="email" value={details.email} onChange={(v) => setDetails({ ...details, email: v })} autoComplete="email" />
              <Field label="Address / Location" value={details.address} onChange={(v) => setDetails({ ...details, address: v })} autoComplete="street-address" />
              <Field label="Preferred Date" type="date" min={todayISO()} value={details.date} onChange={(v) => setDetails({ ...details, date: v })} />
              <label className="block">
                <span className="text-sm font-semibold">Preferred Time</span>
                <select required value={details.time} onChange={(e) => setDetails({ ...details, time: e.target.value })}
                  className="mt-2 h-12 w-full rounded-md border border-input bg-background px-3 text-base focus:outline-none focus:ring-2 focus:ring-ring">
                  <option value="" disabled>Select a time</option>
                  {TIME_SLOTS.map((t) => <option key={t}>{t}</option>)}
                </select>
              </label>
              <button type="submit" className="btn btn-primary sm:col-span-2">Review Booking</button>
            </form>
          </Step>
        )}

        {service === "cleaning" && category?.flow === "form" && reviewing && (
          <Step title="Booking summary" intro="Please check your details, then send the booking on WhatsApp.">
            <div className="rounded-lg border bg-card">
              <dl className="divide-y">
                {[
                  ["Service", "Cleaning Service"],
                  ["Category", category.name],
                  ["Name", details.name],
                  ["Phone", details.phone],
                  ["Email", details.email],
                  ["Address / Location", details.address],
                  ["Preferred Date", fmtDate(details.date)],
                  ["Preferred Time", details.time],
                ].map(([k, v]) => (
                  <div key={k} className="grid gap-1 px-6 py-4 sm:grid-cols-3">
                    <dt className="eyebrow">{k}</dt>
                    <dd className="break-words font-medium sm:col-span-2">{v}</dd>
                  </div>
                ))}
              </dl>
              <div className="flex flex-col gap-3 border-t p-6 sm:flex-row">
                <a
                  href={createWhatsAppLink(
                    `Hello, I would like to book a ${category.name}.\n\nName: ${details.name}\nPhone: ${details.phone}\nEmail: ${details.email}\nAddress: ${details.address}\nPreferred Date: ${fmtDate(details.date)}\nPreferred Time: ${details.time}\n\nThank you.`,
                  )}
                  target="_blank" rel="noopener noreferrer" className="btn btn-whatsapp"
                >
                  <WhatsAppIcon />Send Booking on WhatsApp
                </a>
                <button onClick={() => setReviewing(false)} className="btn btn-outline text-primary">Edit Details</button>
              </div>
              <p className="px-6 pb-6 text-sm text-muted-foreground">WhatsApp will open with your booking message. Press send in WhatsApp to deliver it to us.</p>
            </div>
          </Step>
        )}

        {service === "pest" && (
          <Step title="Which pest do you need treated?" intro="Select one and WhatsApp opens with your enquiry ready. We'll send available options and price.">
            <OptionList items={PEST} message={pestMessage} />
          </Step>
        )}

        {service === "flora" && (
          <Step title="Choose a floriculture service" intro="Select one and WhatsApp opens with your enquiry ready.">
            <OptionList items={FLORA} message={floraMessage} />
          </Step>
        )}
      </div>
    </div>
  );
}

function Step({ title, intro, children }: { title: string; intro?: string; children: React.ReactNode }) {
  return (
    <div>
      <h2 className="text-3xl font-medium">{title}</h2>
      {intro && <p className="mt-2 text-muted-foreground">{intro}</p>}
      <div className="mt-8">{children}</div>
    </div>
  );
}

function OptionList({ items, message }: { items: string[]; message: (s: string) => string }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      {items.map((s) => (
        <a key={s} href={createWhatsAppLink(message(s))} target="_blank" rel="noopener noreferrer"
          className="flex items-center justify-between gap-4 rounded-lg border bg-card p-5 transition-colors hover:border-primary">
          <span className="font-semibold">{s}</span>
          <span className="flex shrink-0 items-center gap-2 text-xs font-bold uppercase tracking-wider text-whatsapp">
            <WhatsAppIcon className="h-4 w-4" />Inquire on WhatsApp
          </span>
        </a>
      ))}
    </div>
  );
}

function Field({ label, value, onChange, type = "text", ...rest }: { label: string; value: string; onChange: (v: string) => void; type?: string } & Omit<React.InputHTMLAttributes<HTMLInputElement>, "onChange" | "value">) {
  return (
    <label className="block">
      <span className="text-sm font-semibold">{label}</span>
      <input required type={type} value={value} onChange={(e) => onChange(e.target.value)} {...rest}
        className="mt-2 h-12 w-full rounded-md border border-input bg-background px-3 text-base focus:outline-none focus:ring-2 focus:ring-ring" />
    </label>
  );
}
