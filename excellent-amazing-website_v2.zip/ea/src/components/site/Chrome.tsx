import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Menu, X, Phone, Mail, MapPin } from "lucide-react";
import { BUSINESS, MSG, createWhatsAppLink, WHATSAPP_NUMBER } from "@/lib/site";

export function WhatsAppIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M17.47 14.38c-.3-.15-1.75-.86-2.02-.96-.27-.1-.47-.15-.67.15-.2.3-.77.96-.94 1.16-.17.2-.35.22-.64.07-.3-.15-1.26-.46-2.4-1.48-.89-.79-1.49-1.77-1.66-2.07-.17-.3-.02-.46.13-.6.13-.14.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.61-.92-2.2-.24-.58-.49-.5-.67-.5h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48s1.06 2.88 1.21 3.08c.15.2 2.1 3.2 5.08 4.48.71.31 1.26.49 1.69.63.71.22 1.36.19 1.87.12.57-.09 1.75-.72 2-1.41.25-.69.25-1.29.17-1.41-.07-.13-.27-.2-.57-.35M12.05 21.5h-.01a9.4 9.4 0 0 1-4.8-1.31l-.34-.2-3.57.94.95-3.48-.22-.36a9.4 9.4 0 0 1-1.44-5.02c0-5.2 4.23-9.43 9.44-9.43 2.52 0 4.89.98 6.67 2.77a9.37 9.37 0 0 1 2.76 6.67c0 5.2-4.23 9.43-9.44 9.43m8.03-17.46A11.3 11.3 0 0 0 12.05.7C5.79.7.7 5.79.7 12.04c0 2 .52 3.95 1.52 5.67L.6 23.6l6.02-1.58a11.3 11.3 0 0 0 5.42 1.38h.01c6.25 0 11.34-5.09 11.35-11.34a11.27 11.27 0 0 0-3.32-8.02" />
    </svg>
  );
}

const NAV = [
  { label: "Home", hash: "" },
  { label: "About", hash: "about" },
  { label: "Services", hash: "services" },
  { label: "Our Work", hash: "work" },
  { label: "How It Works", hash: "how" },
  { label: "Contact", hash: "contact" },
];

function Logo({ light = false }: { light?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-3" aria-label={BUSINESS.name}>
      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-md bg-primary font-display text-lg font-semibold text-primary-foreground">
        EA
      </span>
      <span className="leading-tight">
        <span className={`block font-display text-base font-semibold ${light ? "text-ink-foreground" : "text-foreground"}`}>Excellent Amazing</span>
        <span className={`block text-[0.62rem] font-semibold uppercase tracking-[0.16em] ${light ? "text-ink-foreground/60" : "text-muted-foreground"}`}>
          Cleaning & Pest Control
        </span>
      </span>
    </Link>
  );
}

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b bg-background/95 backdrop-blur">
      <div className="mx-auto flex h-18 max-w-7xl items-center justify-between gap-4 px-5 py-3 lg:px-8">
        <Logo />
        <nav className="hidden items-center gap-7 lg:flex" aria-label="Main">
          {NAV.map((n) => (
            <Link key={n.label} to="/" {...(n.hash ? { hash: n.hash } : {})} className="text-sm font-medium text-foreground/80 hover:text-primary">
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Link to="/book-service" className="btn btn-primary hidden sm:inline-flex">Book a Service</Link>
          <button className="grid h-11 w-11 place-items-center rounded-md border lg:hidden" onClick={() => setOpen(!open)} aria-label="Toggle menu" aria-expanded={open}>
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>
      {open && (
        <div className="border-t bg-background lg:hidden">
          <nav className="mx-auto flex max-w-7xl flex-col px-5 py-4" aria-label="Mobile">
            {NAV.map((n) => (
              <Link key={n.label} to="/" {...(n.hash ? { hash: n.hash } : {})} onClick={() => setOpen(false)} className="border-b py-3.5 text-base font-medium">
                {n.label}
              </Link>
            ))}
            <Link to="/book-service" onClick={() => setOpen(false)} className="btn btn-primary mt-4 w-full">Book a Service</Link>
          </nav>
        </div>
      )}
    </header>
  );
}

export function FloatingWhatsApp() {
  return (
    <a
      href={createWhatsAppLink(MSG.chat)}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat on WhatsApp"
      className="fixed bottom-5 right-5 z-50 grid h-14 w-14 place-items-center rounded-full bg-whatsapp text-whatsapp-foreground shadow-soft transition-transform hover:scale-105"
    >
      <WhatsAppIcon className="h-7 w-7" />
    </a>
  );
}

export function SiteFooter() {
  return (
    <footer className="bg-ink text-ink-foreground">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 py-16 md:grid-cols-2 lg:grid-cols-4 lg:px-8">
        <div className="lg:col-span-1">
          <Logo light />
          <p className="mt-5 text-sm leading-relaxed text-ink-foreground/70">
            {BUSINESS.name} provides cleaning, formigation / pest control and floriculture services in {BUSINESS.location}.
          </p>
        </div>
        <div>
          <h3 className="font-sans text-xs font-bold uppercase tracking-[0.18em] text-accent">Navigation</h3>
          <ul className="mt-5 space-y-3 text-sm text-ink-foreground/80">
            {NAV.map((n) => (
              <li key={n.label}><Link to="/" {...(n.hash ? { hash: n.hash } : {})} className="hover:text-accent">{n.label}</Link></li>
            ))}
            <li><Link to="/book-service" className="hover:text-accent">Book a Service</Link></li>
          </ul>
        </div>
        <div>
          <h3 className="font-sans text-xs font-bold uppercase tracking-[0.18em] text-accent">Services</h3>
          <ul className="mt-5 space-y-3 text-sm text-ink-foreground/80">
            <li>Cleaning Service</li>
            <li>Formigation / Pest Control Service</li>
            <li>Floriculture Service</li>
          </ul>
        </div>
        <div>
          <h3 className="font-sans text-xs font-bold uppercase tracking-[0.18em] text-accent">Contact</h3>
          <ul className="mt-5 space-y-3 text-sm text-ink-foreground/80">
            <li><a href={`tel:${BUSINESS.phoneTel}`} className="flex gap-2 hover:text-accent"><Phone className="mt-0.5 h-4 w-4 shrink-0" />{BUSINESS.phoneDisplay}</a></li>
            <li><a href={createWhatsAppLink(MSG.chat)} target="_blank" rel="noopener noreferrer" className="flex gap-2 hover:text-accent"><WhatsAppIcon className="mt-0.5 h-4 w-4 shrink-0" />WhatsApp: {WHATSAPP_NUMBER}</a></li>
            <li><a href={`mailto:${BUSINESS.email}`} className="flex gap-2 break-all hover:text-accent"><Mail className="mt-0.5 h-4 w-4 shrink-0" />{BUSINESS.email}</a></li>
            <li className="flex gap-2"><MapPin className="mt-0.5 h-4 w-4 shrink-0" />{BUSINESS.address}</li>
          </ul>
          <a href={createWhatsAppLink(MSG.chat)} target="_blank" rel="noopener noreferrer" className="btn btn-whatsapp mt-6"><WhatsAppIcon />Chat on WhatsApp</a>
        </div>
      </div>
      <div className="border-t border-ink-foreground/10">
        <p className="mx-auto max-w-7xl px-5 py-6 text-xs text-ink-foreground/60 lg:px-8">
          © {new Date().getFullYear()} {BUSINESS.name}. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
