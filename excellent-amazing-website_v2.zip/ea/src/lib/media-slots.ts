import { IMG, VIDEOS } from "@/lib/media";

// Every replaceable media position on the website. Positions are fixed:
// the admin dashboard can replace these, never add or remove them.
export type MediaKind = "image" | "video";
export type MediaSlot = { id: string; label: string; group: string; kind: MediaKind; fallback: string; poster?: string };

const img = (id: string, group: string, label: string, fallback: string): MediaSlot => ({ id, group, label, kind: "image", fallback });

export const MEDIA_SLOTS: MediaSlot[] = [
  img("hero.main", "Homepage — Top banner", "Main team photo", IMG.team),
  img("hero.inset", "Homepage — Top banner", "Small overlapping photo", IMG.sofa1),
  img("services.cleaning", "Homepage — Our services", "Cleaning Service card", IMG.sofa3),
  img("services.pest", "Homepage — Our services", "Pest Control card", IMG.bedbugs),
  img("services.flora", "Homepage — Our services", "Floriculture card", IMG.flowerBed),
  img("cleaning.1", "Homepage — Cleaning section", "Large photo", IMG.rug2),
  img("cleaning.2", "Homepage — Cleaning section", "Top-right photo", IMG.mattress1),
  img("cleaning.3", "Homepage — Cleaning section", "Bottom-right photo", IMG.bathroom),
  img("pest.main", "Homepage — Pest control section", "Section photo", IMG.bedbugs),
  img("flora.1", "Homepage — Floriculture section", "Photo 1", IMG.planterTrees),
  img("flora.2", "Homepage — Floriculture section", "Photo 2", IMG.palms),
  img("flora.3", "Homepage — Floriculture section", "Photo 3", IMG.pots),
  ...[
    IMG.sofa1, IMG.sofa2, IMG.sofa3, IMG.rug1, IMG.rug2, IMG.mattress1, IMG.mattress2,
    IMG.headboard, IMG.bathroom, IMG.gateWash, IMG.lawn, IMG.plantPot, IMG.plant, IMG.planters,
  ].map((u, i) => img(`gallery.${i + 1}`, "Our work — Gallery photos", `Gallery photo ${i + 1}`, u)),
  ...VIDEOS.map((v, i): MediaSlot => ({
    id: `video.${i + 1}`, group: "Our work — Videos", label: `Video ${i + 1}`, kind: "video", fallback: v.src, poster: v.poster,
  })),
  img("booking.cleaning", "Booking page", "Cleaning Service choice", IMG.sofa3),
  img("booking.pest", "Booking page", "Pest Control choice", IMG.bedbugs),
  img("booking.flora", "Booking page", "Floriculture choice", IMG.flowerBed),
];

export const SLOT_MAP = Object.fromEntries(MEDIA_SLOTS.map((s) => [s.id, s]));
