// Single source of truth for business details, WhatsApp, services and booking options.

export const BUSINESS = {
  name: "Excellent Amazing Cleaning and Pest Control Services",
  shortName: "Excellent Amazing",
  phoneDisplay: "0901 972 9011",
  phoneTel: "+2349019729011",
  email: "Onyekachitestimonyevan@gmail.com",
  address: "Iyanu, 13B Church Street, Aboru St, Ipaja, Alimosho, Lagos, Nigeria",
  location: "Alimosho, Lagos, Nigeria",
};

export const WHATSAPP_NUMBER = "2349019729011";

export function createWhatsAppLink(message: string) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

export const MSG = {
  letsTalk: "Hello, I would like to make an inquiry about your services.",
  chat: "Hello, I would like to know more about your services.",
};

export const MAP_QUERY = encodeURIComponent(BUSINESS.address);
export const MAP_EMBED = `https://www.google.com/maps?q=${MAP_QUERY}&output=embed`;
export const MAP_DIRECTIONS = `https://www.google.com/maps/dir/?api=1&destination=${MAP_QUERY}`;

// Configurable time slots for the booking form.
export const TIME_SLOTS = [
  "8:00 AM", "9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM",
  "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM",
];

// Confirmed fixed prices only. Leave empty until the business confirms prices.
// Key format: "<category-id>:<tier>", e.g. "sofa:basic": "₦00,000".
export const PRICES: Record<string, string> = {};

export type FormCategory = { id: string; name: string; desc: string; flow: "form" };
export type TierCategory = { id: string; name: string; desc: string; flow: "tier"; item: string };
export type CleaningCategory = FormCategory | TierCategory;

export const CLEANING: CleaningCategory[] = [
  { id: "residential", name: "Residential Cleaning Service", desc: "Thorough cleaning for homes, apartments and duplexes.", flow: "form" },
  { id: "commercial", name: "Commercial / Office Cleaning Service", desc: "Clean, presentable offices and business spaces.", flow: "form" },
  { id: "move", name: "Move-In / Move-Out Cleaning Service", desc: "Get a property ready before you move in or after you move out.", flow: "form" },
  { id: "sofa", name: "Sofa Cleaning", desc: "Fabric and upholstery cleaning for sofas and chairs.", flow: "tier", item: "Sofa Cleaning" },
  { id: "rug", name: "Rug Cleaning", desc: "Careful cleaning for rugs and carpets.", flow: "tier", item: "Rug Cleaning" },
  { id: "mattress", name: "Mattress Cleaning", desc: "Deep fabric cleaning for mattresses and headboards.", flow: "tier", item: "Mattress Cleaning" },
];

export function tierMessage(item: string, tier: "Basic" | "Premium") {
  return `Hello, I would like to book a ${tier} ${item} service. Please provide me with the available booking details. Thank you.`;
}

export const PEST = [
  "Cockroach Control",
  "Ant Control",
  "Mosquito Control",
  "Bedbug Control",
  "Termite Control",
  "Rodent / General Pest Control",
];
export const pestMessage = (s: string) =>
  `Hello, I would like to inquire about your ${s} service. Please provide me with the available options and price. Thank you.`;

export const FLORA = [
  "Landscaping",
  "Flower Planting",
  "Plant Renewal & Healthy Plant Care",
  "Garden Creation",
  "Garden Maintenance",
  "Flower & Gardening Material Supply",
  "Flower Trimming",
  "Manure Supply",
];
export const floraMessage = (s: string) =>
  `Hello, I am interested in your ${s} service. Please provide me with more information, available options and pricing. Thank you.`;

export const REVIEWS = [
  {
    name: "James Williams",
    text: "I contacted Excellent Amazing for pest control in place at Ikotun and I was very pleased with the service. They were professional, explained the treatment clearly, and worked carefully throughout the property. The service was well organized and I would recommend them for pest control.",
  },
  {
    name: "Priya Sharma",
    text: "I am so impressed by what I got from Excellent Amazing cleaning I book them for cleaning and flower decoration in my house when we are moving in to our new place in Alimosho and they deliver amazingly",
  },
  {
    name: "Adiat Roseedat",
    text: "We booked them for bedbug fumigation in Alimosho and the treatment was effective. Very professional and responsive.",
  },
];
