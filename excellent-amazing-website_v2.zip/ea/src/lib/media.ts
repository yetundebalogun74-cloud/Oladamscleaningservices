const m = (f: string) => `/media/${f}`;

export const IMG = {
  team: m("team.jpg"), sofa1: m("sofa-1.jpg"), sofa2: m("sofa-2.jpg"), sofa3: m("sofa-3.jpg"),
  gateWash: m("gate-wash.jpg"), mattress1: m("mattress-1.jpg"), mattress2: m("mattress-2.jpg"),
  bathroom: m("bathroom.jpg"), rug1: m("rug-1.jpg"), rug2: m("rug-2.jpg"), headboard: m("headboard.jpg"),
  pots: m("pots.jpg"), lawn: m("lawn.jpg"), planters: m("planters.jpg"), palms: m("palms.jpg"),
  planterTrees: m("planter-trees.jpg"), bedbugs: m("bedbugs.jpg"), plantPot: m("plant-pot.jpg"),
  flowerBed: m("flower-bed.jpg"), plant: m("plant.jpg"),
};

export const VIDEOS = [1, 2, 3].map((i) => ({ src: m(`video-${i}.mp4`), poster: m(`video-${i}-poster.jpg`) }));
