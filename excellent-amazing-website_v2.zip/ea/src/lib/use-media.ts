import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { SLOT_MAP } from "@/lib/media-slots";

export type Override = { slot: string; url: string; storage_path: string | null };

export const overridesQuery = {
  queryKey: ["media-overrides"],
  queryFn: async (): Promise<Override[]> => {
    const { data, error } = await supabase.from("media_overrides").select("slot,url,storage_path");
    if (error) throw error;
    return data ?? [];
  },
  staleTime: 30_000,
};

/** Returns m(slotId) -> current URL (replacement if set, otherwise the original). */
export function useMedia() {
  const { data } = useQuery({ ...overridesQuery, enabled: typeof window !== "undefined" });
  const map = new Map((data ?? []).map((o) => [o.slot, o.url]));
  const m = (id: string) => map.get(id) ?? SLOT_MAP[id]?.fallback ?? "";
  const poster = (id: string) => (map.has(id) ? undefined : SLOT_MAP[id]?.poster);
  return { m, poster };
}
