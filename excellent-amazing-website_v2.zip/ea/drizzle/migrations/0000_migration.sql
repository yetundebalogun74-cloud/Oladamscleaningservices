create type public.app_role as enum ('admin');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "Users read own roles" on public.user_roles for select to authenticated using (user_id = auth.uid());

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

-- Only the designated administrator email ever receives the admin role.
create or replace function public.grant_admin_for_owner()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if lower(new.email) = 'yetundebalogun74@gmail.com' then
    insert into public.user_roles (user_id, role) values (new.id, 'admin') on conflict do nothing;
  end if;
  return new;
end $$;
create trigger on_auth_user_created_grant_admin after insert on auth.users
  for each row execute function public.grant_admin_for_owner();

create table public.media_overrides (
  slot text primary key,
  url text not null,
  storage_path text,
  updated_at timestamptz not null default now()
);
grant select on public.media_overrides to anon, authenticated;
grant insert, update, delete on public.media_overrides to authenticated;
grant all on public.media_overrides to service_role;
alter table public.media_overrides enable row level security;
create policy "Anyone can view media" on public.media_overrides for select to anon, authenticated using (true);
create policy "Admins insert media" on public.media_overrides for insert to authenticated with check (public.has_role(auth.uid(), 'admin'));
create policy "Admins update media" on public.media_overrides for update to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));
create policy "Admins delete media" on public.media_overrides for delete to authenticated using (public.has_role(auth.uid(), 'admin'));

create policy "Admins upload site media" on storage.objects for insert to authenticated with check (bucket_id = 'site-media' and public.has_role(auth.uid(), 'admin'));
create policy "Admins update site media" on storage.objects for update to authenticated using (bucket_id = 'site-media' and public.has_role(auth.uid(), 'admin'));
create policy "Admins delete site media" on storage.objects for delete to authenticated using (bucket_id = 'site-media' and public.has_role(auth.uid(), 'admin'));